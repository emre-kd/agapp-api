<?php echo e($slot); ?>

<?php /**PATH C:\Users\EmreKaradereli\Desktop\Projeler\laravel-sanctum\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>